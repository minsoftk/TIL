# 몸풀기
# import this
import sys

# 파이썬 기본 인코딩 utf-8
print(sys.stdin.encoding)
print(sys.stdout.encoding)

# 클래스
class Cookie:
	pass
# 객체생성
cookie = Cookie()

print(id(cookie))
print(dir(cookie))
