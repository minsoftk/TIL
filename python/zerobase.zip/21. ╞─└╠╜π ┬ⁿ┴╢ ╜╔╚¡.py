import copy
print("minsoftk", "gmail.com", sep='@')
