def prt1():
    print("I'm niceboy")


def prt2():
    print("I'm goodboy")


# 단위 실행(독립적으로 파일 실행)
if __name__ == "__main__":
    print("This is", dir())
    prt1()
    prt2()
